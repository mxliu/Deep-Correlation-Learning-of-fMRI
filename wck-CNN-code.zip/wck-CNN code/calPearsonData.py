#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  1 11:13:56 2017

@author: biaojie
"""

from __future__ import print_function
#import scipy.io as scio  
import numpy as np 

def calPeason(timeSeries,flag=0):
    A=timeSeries 
    nd=A.shape
    #nd=[2,2,116]
    ts_data=np.zeros((nd[0],nd[1]*nd[1],nd[2]))#np.array([0]*nd[0],[0]*nd[1]*nd[1],[0]*nd[2])
    B=np.zeros((nd[1],nd[2]))
    for n_i in range(nd[0]):
        ic=-1
        if flag==0:
            for r_i in range(nd[1]):
                aa=A[n_i,r_i,:]
                for r_i2 in range(nd[1]):
                    bb=A[n_i,r_i2,:]
                    ic=ic+1                
                    ts_data[n_i,ic,:]=aa*bb
        if flag==1:
            B[:,:]=A[n_i,:,:]
            C=np.sqrt(np.sum(np.power(B,2),1))
            for r_i in range(nd[1]):
                aa=B[r_i,:]
                for r_i2 in range(nd[1]):
                    bb=B[r_i2,:]
                    ic=ic+1                
                    ts_data[n_i,ic,:]=aa*bb/(C[r_i]*C[r_i2])
    return ts_data
#np.save("nki_ts_data.npy",ts_data)           



