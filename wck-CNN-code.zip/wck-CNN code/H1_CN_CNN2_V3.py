#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 15:07:25 2017

@author: biaojie
"""
from keras.models import Model
from keras.layers import Input,Dense, Dropout, Flatten,Activation
from keras.layers import Conv2D,BatchNormalization,AveragePooling2D
import math
def brainPeasonCNN(inputs,num_class,roi_n=116,ts_n=137,ker_size=[16,32,32,64,128,64,32]):
    
    tp_len=70
    tp_step=2;
    ratio_drop=0.25
    k1=8
    k2=8
    s1=int(math.floor(float(ts_n-tp_len)/tp_step))
    s2=int(math.floor(float(s1-k1)/2))+1    
    #s3=int(math.floor(float(s2-k2)/2))+1


    l1=Conv2D(ker_size[0], kernel_size=(1, 70),strides=(1,2), use_bias=False)(inputs)
    l1=BatchNormalization()(l1)
    l1=Activation('relu')(l1)
    l1=Dropout(ratio_drop)(l1)
    l2=Conv2D(ker_size[1], kernel_size=(roi_n, 2),strides=(roi_n,1))(l1)
    l2=BatchNormalization()(l2)
    l2=Activation('relu')(l2)
    l2=Dropout(ratio_drop)(l2)
    l3=Conv2D(ker_size[2], kernel_size=(roi_n, 2),strides=(roi_n,1))(l2)
    l3=BatchNormalization()(l3)
    l3=Activation('relu')(l3)
    l3=Dropout(ratio_drop)(l3)  

    """
    l4=Conv2D(ker_size[3], kernel_size=(1, k1),strides=(1,2))(l3)
    l4=BatchNormalization()(l4)
    l4=Activation('relu')(l4) 
    l4=Dropout(ratio_drop)(l4)
    """
    l4=Conv2D(ker_size[3], kernel_size=(1, k1),strides=(1,2))(l3)
    l4=BatchNormalization()(l4)
    l4=Activation('relu')(l4) 
    
    l4_2=AveragePooling2D(pool_size=(1,s2),strides=(1,1))(l4)
   
    l4_2=Dropout(0.5)(l4_2)
    l5=Flatten()(l4_2)
    l6=l5
    """
    if num_class>1:
        l6=Dense(ker_size[4])(l6)
        l6=BatchNormalization()(l6)
        l6=Activation('relu')(l6)
        l6=Dropout(0.5)(l6)
    """    
    l7=Dense(ker_size[5])(l6)
    l7=BatchNormalization()(l7)
    l7=Activation('relu')(l7)
    l7=Dropout(0.5)(l7)
    l8=Dense(ker_size[6])(l7)
    l8=BatchNormalization()(l8)
    l8=Activation('relu')(l8)
    
    l9=Dense(num_class)(l8)
        
    if num_class>1:
        l9=BatchNormalization()(l9)
        l9=Activation('softmax')(l9) 
  
    outputs=l9
    return outputs

if __name__=='__main__':
    roi_n=116
    ts_n=116
    input_shape=(13456,ts_n,1)
    inputs=Input(shape=input_shape) 
    outputs=brainPeasonCNN(inputs,4,roi_n=roi_n,ts_n=ts_n)
    model=Model(inputs=inputs,outputs=outputs)
    model.summary()
